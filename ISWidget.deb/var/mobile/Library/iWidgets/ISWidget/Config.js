// Configuration Clock //



	var ampm = false;	  // change to true to display 12h clock



// Configuration Weather //



       var isCelsius = true    // change to false to display degrees in Farenheit



// Configuration Language //

     

	var French = false;	 // change to true to display weather and date in French

	var German = false;	 // change to true to display weather and date in German

	var Spanish = false;	 // change to true to display weather and date in Spanish

	var Dutch = false;	 // change to true to display date in Dutch

	var Italian = false;	 // change to true to display date in Italian